package com.yg.view;


import android.content.res.TypedArray;
import android.util.Log;
import android.view.View;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.yg.multiseekbar.R;

import java.math.BigDecimal;


/**
 * Created by baijunfeng on 18/6/22.
 */
public class MultiSeekBar extends View {
    private static final String TAG = "MultiSeekBar";
    private static final int CLICK_ON_LOW = 1;      //点击在前滑块上
    private static final int CLICK_ON_HIGH = 2;     //点击在后滑块上
    private static final int CLICK_IN_LOW_AREA = 3;
    private static final int CLICK_IN_HIGH_AREA = 4;
    private static final int CLICK_OUT_AREA = 5;
    private static final int CLICK_INVAILD = 0;

    /*
     * 滑动块按下之后的状态记录，可以根据这个记录配置不同的滑动块显示效果
     */
    private static final int[] STATE_NORMAL = {android.R.attr.state_empty};
    private static final int[] STATE_PRESSED = {
            android.R.attr.state_pressed, android.R.attr.state_window_focused,
    };
    private Drawable mSeekBarFg;        //滑动条前景色
    private Drawable mSeekBarBg;        //滑动条背景色
    private Drawable mThumbStart;         //前滑块
    private Drawable mThumbEnd;        //后滑块

    private int mThumbWidth;        //滑动块宽度
    private int mThumbHeight;       //滑动块高度

    private int mSeekBarWidth;     //控件宽度=滑动条宽度+滑动块宽度
    private int mSeekBarHeight;    //滑动条高度

    int mMinWidth;
    int mMaxWidth;
    int mMinHeight;
    int mMaxHeight;

    private double mOffsetStart = 0;     //前滑块中心坐标
    private double mOffsetEnd = 0;    //后滑块中心坐标
    private int mDistance = 0;      //总刻度是固定距离 两边各去掉半个滑块距离

    //控件内部四面预留空间，用于显示可能需要显示的内容
    private int mThumbMarginTop = 0;
    private int mThumbMarginLeft = 0;
    private int mThumbMarginRight = 0;
    private int mThumbMarginBottom = 0;

    private int mFlag = CLICK_INVAILD;
    private OnSeekBarChangeListener mBarChangeListener;


    private double defaultScreenLow = 0;    //默认前滑块位置百分比
    private double defaultScreenHigh = 100;  //默认后滑块位置百分比

    private boolean isEdit = false;     //输入框是否正在输入

    Context mContext;

    public MultiSeekBar(Context context) {
        this(context, null);
    }

    public MultiSeekBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MultiSeekBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
//        this.setBackgroundColor(Color.BLACK);
        initProgressBar();

        final TypedArray a = context.obtainStyledAttributes(
                attrs, R.styleable.MultiSeekBar, defStyle, defStyle);

        mSeekBarBg = a.getDrawable(R.styleable.MultiSeekBar_background);
        mSeekBarFg = a.getDrawable(R.styleable.MultiSeekBar_foreground);
        mThumbStart = a.getDrawable(R.styleable.MultiSeekBar_thumb_start);
        mThumbEnd = a.getDrawable(R.styleable.MultiSeekBar_thumb_end);

        Resources resources = getResources();

        if (mSeekBarBg == null) {
            mSeekBarBg = resources.getDrawable(R.drawable.seekbar_background);
        }
        if (mSeekBarBg == null) {
            mSeekBarBg = resources.getDrawable(R.drawable.seekbar_foreground);
        }
        if (mThumbStart == null) {
            mThumbStart = resources.getDrawable(R.drawable.selector_thumb_start);
        }
        if (mThumbEnd == null) {
            mThumbEnd = resources.getDrawable(R.drawable.selector_thumb_start);
        }

        mThumbStart.setState(STATE_NORMAL);
        mThumbEnd.setState(STATE_NORMAL);

        mSeekBarWidth = mSeekBarBg.getIntrinsicWidth();
        mSeekBarHeight = mSeekBarBg.getIntrinsicHeight();
//        mSeekBarHeight = mMinHeight;
//        mSeekBarWidth = mMaxWidth;

        mThumbWidth = mThumbStart.getIntrinsicWidth();
        mThumbHeight = mThumbStart.getIntrinsicHeight();

    }

    private void initProgressBar() {
//        mMax = 100;
        mMinWidth = 24;
        mMaxWidth = 48;
        mMinHeight = 24;
        mMaxHeight = 48;
    }

    //默认执行，计算view的宽高,在onDraw()之前
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = measureWidth(widthMeasureSpec);
//        int height = measureHeight(heightMeasureSpec);
        mSeekBarWidth = width;
        mOffsetEnd = width - mThumbWidth / 2;
        mOffsetStart = mThumbWidth / 2;
        mDistance = width - mThumbWidth;

        mOffsetStart = formatDouble(defaultScreenLow / 100 * (mDistance ))+ mThumbWidth / 2;
        mOffsetEnd = formatDouble(defaultScreenHigh / 100 * (mDistance)) + mThumbWidth / 2;
        setMeasuredDimension(width, mThumbHeight + mThumbMarginTop+2);
    }


    private int measureWidth(int measureSpec) {
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        //wrap_content
        if (specMode == MeasureSpec.AT_MOST) {
        }
        //fill_parent或者精确值
        else if (specMode == MeasureSpec.EXACTLY) {
        }

        return specSize;
    }

    private int measureHeight(int measureSpec) {
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        int defaultHeight = 100;
        //wrap_content
        if (specMode == MeasureSpec.AT_MOST) {
        }
        //fill_parent或者精确值
        else if (specMode == MeasureSpec.EXACTLY) {
            defaultHeight = specSize;
        }

        return defaultHeight;
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint text_Paint = new Paint();
        text_Paint.setTextAlign(Paint.Align.CENTER);
        text_Paint.setColor(Color.WHITE);
        text_Paint.setTextSize(sp2px(11));

        int aaa = mThumbMarginTop + mThumbHeight / 2 - mSeekBarHeight / 2;
        int bbb = aaa + mSeekBarHeight;

        //白色，不会动
        mSeekBarBg.setBounds(mThumbWidth / 2, aaa, mSeekBarWidth - mThumbWidth / 2, bbb);
        mSeekBarBg.draw(canvas);

        //蓝色，中间部分会动
        mSeekBarFg.setBounds((int) mOffsetStart, aaa, (int) mOffsetEnd, bbb);
        mSeekBarFg.draw(canvas);

        //前滑块
        mThumbStart.setBounds((int)(mOffsetStart - mThumbWidth / 2), mThumbMarginTop, (int)(mOffsetStart + mThumbWidth / 2), mThumbHeight + mThumbMarginTop);
        mThumbStart.draw(canvas);

        //后滑块
        mThumbEnd.setBounds((int)(mOffsetEnd - mThumbWidth / 2), mThumbMarginTop, (int)(mOffsetEnd + mThumbWidth / 2), mThumbHeight + mThumbMarginTop);
        mThumbEnd.draw(canvas);

        double progressLow = formatDouble((mOffsetStart - mThumbWidth / 2) * 25 / mDistance);
        double progressHigh = formatDouble((mOffsetEnd - mThumbWidth / 2) * 25 / mDistance);
        String textLow = (int)progressLow + "K";
        String textHigh = (int)progressHigh + "K";
//            Log.d(TAG, "onDraw-->mOffsetStart: " + mOffsetStart + "  mOffsetEnd: " + mOffsetEnd   + "  progressLow: " + progressLow + "  progressHigh: " + progressHigh);

        canvas.drawText(textLow, (int) mOffsetStart, dipToPixel(12), text_Paint);
        canvas.drawText(textHigh, (int) mOffsetEnd, dipToPixel(12), text_Paint);

        if (mBarChangeListener != null) {
            if (!isEdit) {
                mBarChangeListener.onProgressChanged(this, progressLow, progressHigh);
            }

        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        //按下
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            if (mBarChangeListener != null) {
                mBarChangeListener.onProgressBefore();
                isEdit = false;
            }
            mFlag = getAreaFlag(e);
//            Log.d(TAG, "e.getX: " + e.getX() + "mFlag: " + mFlag);
            Log.d(TAG, "ACTION_DOWN");
            if (mFlag == CLICK_ON_LOW) {
                mThumbStart.setState(STATE_PRESSED);
            } else if (mFlag == CLICK_ON_HIGH) {
                mThumbEnd.setState(STATE_PRESSED);
            } else if (mFlag == CLICK_IN_LOW_AREA) {
                mThumbStart.setState(STATE_PRESSED);
                //如果点击0-mThumbWidth/2坐标
                if (e.getX() < 0 || e.getX() <= mThumbWidth/2) {
                    mOffsetStart = mThumbWidth/2;
                } else if (e.getX() > mSeekBarWidth - mThumbWidth/2) {
//                    mOffsetStart = mDistance - mDuration;
                    mOffsetStart = mThumbWidth/2 + mDistance;
                } else {
                    mOffsetStart = formatDouble(e.getX());
//                    if (mOffsetEnd<= mOffsetStart) {
//                        mOffsetEnd = (mOffsetStart + mDuration <= mDistance) ? (mOffsetStart + mDuration)
//                                : mDistance;
//                        mOffsetStart = mOffsetEnd - mDuration;
//                    }
                }
            } else if (mFlag == CLICK_IN_HIGH_AREA) {
                mThumbEnd.setState(STATE_PRESSED);
//                if (e.getX() < mDuration) {
//                    mOffsetEnd = mDuration;
//                    mOffsetStart = mOffsetEnd - mDuration;
//                } else if (e.getX() >= mSeekBarWidth - mThumbWidth/2) {
//                    mOffsetEnd = mDistance + mThumbWidth/2;
                if(e.getX() >= mSeekBarWidth - mThumbWidth/2) {
                    mOffsetEnd = mDistance + mThumbWidth/2;
                } else {
                    mOffsetEnd = formatDouble(e.getX());
//                    if (mOffsetEnd <= mOffsetStart) {
//                        mOffsetStart = (mOffsetEnd - mDuration >= 0) ? (mOffsetEnd - mDuration) : 0;
//                        mOffsetEnd = mOffsetStart + mDuration;
//                    }
                }
            }
            //设置进度条
            refresh();

            //移动move
        } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
//            Log.d("ACTION_MOVE", "------------------");
            if (mFlag == CLICK_ON_LOW) {
                if (e.getX() < 0 || e.getX() <= mThumbWidth/2) {
                    mOffsetStart = mThumbWidth/2;
                } else if (e.getX() >= mSeekBarWidth - mThumbWidth/2) {
                    mOffsetStart = mThumbWidth/2 + mDistance;
                    mOffsetEnd = mOffsetStart;
                } else {
                    mOffsetStart = formatDouble(e.getX());
                    if (mOffsetEnd - mOffsetStart <= 0) {
                        mOffsetEnd = (mOffsetStart <= mDistance+mThumbWidth/2) ? (mOffsetStart) : (mDistance+mThumbWidth/2);
                    }
                }
            } else if (mFlag == CLICK_ON_HIGH) {
                if (e.getX() <  mThumbWidth/2) {
                    mOffsetEnd = mThumbWidth/2;
                    mOffsetStart = mThumbWidth/2;
                } else if (e.getX() > mSeekBarWidth - mThumbWidth/2) {
                    mOffsetEnd = mThumbWidth/2 + mDistance;
                } else {
                    mOffsetEnd = formatDouble(e.getX());
                    if (mOffsetEnd - mOffsetStart <= 0) {
                        mOffsetStart = (mOffsetEnd >= mThumbWidth/2) ? (mOffsetEnd) : mThumbWidth/2;
                    }
                }
            }
            //设置进度条
            refresh();
            //抬起
        } else if (e.getAction() == MotionEvent.ACTION_UP) {
            Log.d(TAG, "ACTION_UP");
            mThumbStart.setState(STATE_NORMAL);
            mThumbEnd.setState(STATE_NORMAL);

            if (mBarChangeListener != null) {
                mBarChangeListener.onProgressAfter();
            }
            refresh();
            //这两个for循环 是用来自动对齐刻度的，注释后，就可以自由滑动到任意位置
//            for (int i = 0; i < money.length; i++) {
//                 if(Math.abs(mOffsetStart-i* ((mSeekBarWidth-mThumbWidth)/ (money.length-1)))<=(mSeekBarWidth-mThumbWidth)/(money.length-1)/2){
//                     mprogressLow=i;
//                     mOffsetStart =i* ((mSeekBarWidth-mThumbWidth)/(money.length-1));
//                     invalidate();
//                     break;
//                }
//            }
//
//            for (int i = 0; i < money.length; i++) {
//                  if(Math.abs(mOffsetEnd-i* ((mSeekBarWidth-mThumbWidth)/(money.length-1) ))<(mSeekBarWidth-mThumbWidth)/(money.length-1)/2){
//                      mprogressHigh=i;
//                       mOffsetEnd =i* ((mSeekBarWidth-mThumbWidth)/(money.length-1));
//                       invalidate();
//                       break;
//                }
//            }
        }
        return true;
    }

    public int getAreaFlag(MotionEvent e) {

        int top = mThumbMarginTop;
        int bottom = mThumbHeight + mThumbMarginTop;
        if (e.getY() >= top && e.getY() <= bottom && e.getX() >= (mOffsetStart - mThumbWidth / 2) && e.getX() <= mOffsetStart + mThumbWidth / 2) {
            return CLICK_ON_LOW;
        } else if (e.getY() >= top && e.getY() <= bottom && e.getX() >= (mOffsetEnd - mThumbWidth / 2) && e.getX() <= (mOffsetEnd + mThumbWidth / 2)) {
            return CLICK_ON_HIGH;
        } else if (e.getY() >= top
                && e.getY() <= bottom
                && ((e.getX() >= 0 && e.getX() < (mOffsetStart - mThumbWidth / 2)) || ((e.getX() > (mOffsetStart + mThumbWidth / 2))
                && e.getX() <= ((double) mOffsetEnd + mOffsetStart) / 2))) {
            return CLICK_IN_LOW_AREA;
        } else if (e.getY() >= top
                && e.getY() <= bottom
                && (((e.getX() > ((double) mOffsetEnd + mOffsetStart) / 2) && e.getX() < (mOffsetEnd - mThumbWidth / 2)) || (e
                .getX() > (mOffsetEnd + mThumbWidth/2) && e.getX() <= mSeekBarWidth))) {
            return CLICK_IN_HIGH_AREA;
        } else if (!(e.getX() >= 0 && e.getX() <= mSeekBarWidth && e.getY() >= top && e.getY() <= bottom)) {
            return CLICK_OUT_AREA;
        } else {
            return CLICK_INVAILD;
        }
    }

    //更新滑块
    private void refresh() {
        invalidate();
    }

    //设置前滑块的值
    public void setProgressLow(double  progressLow) {
        this.defaultScreenLow = progressLow;
        mOffsetStart = formatDouble(progressLow / 100 * (mDistance ))+ mThumbWidth / 2;
        isEdit = true;
        refresh();
    }

    //设置后滑块的值
    public void setProgressHigh(double  progressHigh) {
        this.defaultScreenHigh = progressHigh;
        mOffsetEnd = formatDouble(progressHigh / 100 * (mDistance)) + mThumbWidth / 2;
        isEdit = true;
        refresh();
    }

    public void setOnSeekBarChangeListener(OnSeekBarChangeListener mListener) {
        this.mBarChangeListener = mListener;
    }

    //回调函数，在滑动时实时调用，改变输入框的值
    public interface OnSeekBarChangeListener {
        //滑动前
        public void onProgressBefore();

        //滑动时
        public void onProgressChanged(MultiSeekBar seekBar, double progressLow,
                                      double progressHigh);

        //滑动后
        public void onProgressAfter();
    }

/*    private int formatInt(double value) {
        BigDecimal bd = new BigDecimal(value);
        BigDecimal bd1 = bd.setScale(0, BigDecimal.ROUND_HALF_UP);
        return bd1.intValue();
    }*/

    public static double formatDouble(double pDouble) {
        BigDecimal bd = new BigDecimal(pDouble);
        BigDecimal bd1 = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        pDouble = bd1.doubleValue();
        return pDouble;
    }

    /**
     * 根据手机的分辨率从 dip 的单位 转成为 pixel(像素)
     */
    public int dipToPixel(float dip) {
        float scale = mContext.getResources().getDisplayMetrics().density;
        return (int) (dip * scale + 0.5f);
    }

    /**
     * 根据手机的分辨率从 pixel(像素) 的单位 转成为 dip
     */
    public int pixelToDip(float px) {
        float scale = mContext.getResources().getDisplayMetrics().density;
        return (int) (px / scale + 0.5f);
    }

    public int sp2px(float sp) {
        final float fontScale = mContext.getResources().getDisplayMetrics().scaledDensity;
        return (int) (sp * fontScale + 0.5f);
    }
}