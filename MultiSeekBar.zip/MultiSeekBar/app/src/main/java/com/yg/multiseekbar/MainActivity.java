package com.yg.multiseekbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SeekBar seekBar = (SeekBar) findViewById(R.id.test_seekbar);
        seekBar.setThumb(getResources().getDrawable(R.drawable.ic_thumb));

        boolean a = android.provider.Settings.System.putString(getContentResolver(), "domSetting", "333");
        Log.d("baijf1", "a = " + a);
        String s = android.provider.Settings.System.getString(getContentResolver(), "domSetting");
        Log.d("baijf1", "s = " + s);
    }
}
